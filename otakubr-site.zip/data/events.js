export const events = [
  { date: "10 Ago", title: "Watch party: final de temporada", where: "Discord", type: "online" },
  { date: "17 Ago", title: "Encontro em SP: Liberdade + Karaoke", where: "São Paulo/SP", type: "offline" },
  { date: "24 Ago", title: "Clube do mangá: Vinland Saga", where: "Discord", type: "online" }
];
