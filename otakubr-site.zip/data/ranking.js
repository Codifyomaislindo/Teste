export const ranking = [
  { name: "OPM", votos: 320 },
  { name: "AOT", votos: 298 },
  { name: "JJK", votos: 275 },
  { name: "OP", votos: 260 },
  { name: "DS", votos: 210 }
];
